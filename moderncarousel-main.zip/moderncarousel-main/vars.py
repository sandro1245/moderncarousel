fps = 1000
dro = 1/fps



carousel_indicator_minopacity = 0.2