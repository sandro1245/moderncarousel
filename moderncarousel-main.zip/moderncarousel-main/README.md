# moderncarousel
Modern-carousel is Python Kivy libary component that is upgraded and modern version of Kivy's traditional Carousel, which has really bad animation and is hard to interact with.
