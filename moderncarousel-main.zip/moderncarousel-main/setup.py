from setuptools import setup

setup(
   name='moderncarousel',
   version='1.0',
   description='Kivy component',
   author='moderncarousel',
   author_email='@.example',
   packages=['moderncarousel'],
   install_requires=['kivy'] 
)
